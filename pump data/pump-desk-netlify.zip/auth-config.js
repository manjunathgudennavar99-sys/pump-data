// ------------------------------------------------------------------
// Pump Desk sign-in settings (Firebase Authentication)
//
// * Leave apiKey empty ("")  -> NO login page. The app opens directly.
// * Fill in the four Firebase details below -> the login page turns on.
//
// Where to find the four details: Firebase console > Project settings >
// General > Your apps > Web app > "SDK setup and configuration" > Config.
// ------------------------------------------------------------------
window.PUMP_AUTH = {
  firebase: {
    apiKey: "",
    authDomain: "",   // looks like  my-pump.firebaseapp.com
    projectId: "",
    appId: ""
  },

  // Show only the sign-in methods you have switched ON in Firebase.
  // Choose from: "google", "apple", "microsoft", "facebook", "github",
  //              "twitter", "yahoo", "password"   (password = email + password)
  providers: ["google", "apple", "password"],

  // true = also show "Continue without signing in" (anyone can then skip the login)
  allowGuest: false
};
