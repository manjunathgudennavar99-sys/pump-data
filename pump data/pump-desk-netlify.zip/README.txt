PUMP DESK - put it on Netlify, then (optionally) turn on the login page
=======================================================================

This folder is a complete website. The only file the app needs is index.html.
auth-config.js holds the login settings. The other files (netlify.toml, manifest,
icons) make it install nicely on a phone.


PART 1 - PUT IT ON THE INTERNET
-------------------------------
EASIEST (no GitHub):
1. Open https://app.netlify.com/drop
2. Drag this whole folder onto the page. Your site address appears in a few seconds.

THROUGH GITHUB:
1. Make a new repository on GitHub.
2. Add file > Upload files. Drag in ALL files from this folder. index.html must be at the
   top level of the repository (not inside a folder) and named exactly index.html.
3. Commit changes.
4. Netlify: Add new site > Import an existing project > GitHub > pick the repository.
5. Branch: main. Base directory: empty. Build command: empty. Publish directory: empty (or a dot).
6. Deploy.

If you see "Something went wrong" while picking the repository, Netlify has no access to it:
GitHub > Settings > Applications > Netlify > Configure > Repository access > add the repository.
"Page not found" = index.html is not at the top level or is named differently.
"Build failed" = clear the Build command box. If anything still fails, use the EASIEST way.


PART 2 - TURN ON THE LOGIN PAGE (Google, Apple and more)
--------------------------------------------------------
Until you do this the app opens without a login. That is on purpose, so you can never be locked out.

1. Go to https://console.firebase.google.com and click Add project (the free plan is enough).
2. Build > Authentication > Get started.
3. Sign-in method tab: turn on the methods you want (see the list below).
4. Authentication > Settings > Authorized domains > Add domain: your Netlify address,
   for example  my-pump.netlify.app  (and your own domain if you add one).
5. Project settings (gear icon) > General > Your apps > click the web icon  </>  > register the app.
   Copy the four values (apiKey, authDomain, projectId, appId).
6. Open auth-config.js in this folder, paste the four values between the quotes, and list in
   "providers" only the methods you switched on.
7. Upload the changed auth-config.js again (drag the folder onto Netlify Drop again, or
   commit the file to GitHub). Reload the site: the login page appears.

WHAT EACH METHOD NEEDS
- Google ........ just switch it on and add a support email. Free, takes a minute.
- Email + password ("password") .. just switch it on. Free.
- Microsoft ..... an Azure app registration (client ID and secret).
- Facebook ...... a Meta developer app (app ID and secret).
- GitHub ........ a GitHub OAuth app (client ID and secret).
- X (Twitter) ... an X developer app (API key and secret).
- Yahoo ......... a Yahoo developer app.
- Apple ......... needs a paid Apple Developer account (about 99 US dollars a year): a Services ID,
                  Team ID, Key ID and a private key. Firebase shows the exact fields.
For each one, the provider's website asks for a "redirect URL". Firebase shows it to you on the
same screen where you switch the method on. Copy it into the provider's settings.

Phone-number (SMS) login is not included. It needs extra setup and costs per message.

IMPORTANT TO KNOW
- The login decides who can open the app on a device. Records are still saved in each
  phone's browser, so signing in on a second phone shows an empty app. To share the same records
  between phones, the app needs a cloud database. That is a separate step: ask for it.
- On iPhone, if the Google or Apple window does not open, the app switches to a full-page sign-in
  by itself. That is normal.


ON THE PHONE
- Open the site address in Chrome (Android) or Safari (iPhone).
- Android: menu > Add to Home screen. iPhone: Share > Add to Home Screen.
- Always use the same address and browser. Records are saved in that browser.


MOVING YOUR DATA FROM THE CLAUDE VERSION
A new website starts empty.
1. Old version: Settings > Backup and restore > Copy backup.
2. New site: Settings > Backup and restore, paste into the box, tap Restore twice.
Do this before you record anything on the new site. Restore replaces what is there.


EXCEL
On your own site, Export to Excel opens a small sheet. "Share or save the Excel file" and
"Try downloading the .xlsx file" normally work in a phone browser. "Copy for Excel" always works.
